using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using UnityEngine.Events;
using UnityEditor;

public enum InteractionType
{
    GenerateCards,
    StartDialogue,
    StartMoving,
    StartTypingGame
}

public class InteractableOptions : MonoBehaviour
{
    private DialogueSystem dialogueSystem;
    private MemoryGameController memoryGameController;

    private InteractionType interactionType;
    public InteractionType InteractionType { get => interactionType; set => interactionType = value; }

    private int iD;
    public int ID { get => iD; set => iD = value; }

    private MovableObject movableObject;
    public MovableObject MovableObject { get => movableObject; set => movableObject = value; }

    public static bool possibleInteract = true;
    private bool isPlayerInTrigger = false;

    [SerializeField] private bool justAnInterraction = false;

    void Start()
    {
        memoryGameController = FindObjectOfType<MemoryGameController>();
        dialogueSystem = FindObjectOfType<DialogueSystem>();
    }

    void Update()
    {
        if (possibleInteract)
        {
            if (Input.GetKeyDown(UIManager.instance.dialogueKey) && isPlayerInTrigger)
            {
                if (!UIManager.instance.IsInterractionActive())
                {
                    ExecuteInteraction();
                    UIManager.instance.ShowInteractablePanel(false);
                    PlayerOutTrigger();
                }
            }
        }
    }

    private void ExecuteInteraction()
    {
        if (justAnInterraction) { StopInterract(); }
        switch (InteractionType)
        {
            case InteractionType.GenerateCards:
                memoryGameController?.StartMemoryGame();
                break;

            case InteractionType.StartDialogue:
                dialogueSystem?.StartDialogue(ID);
                break;
            
            case InteractionType.StartMoving:
                MovableObject.StartMoving();
                break;

            case InteractionType.StartTypingGame:
                GameManager.instance.TypingGameStart();
                break;
        }
    }

    public void PlayerInTrigger() => isPlayerInTrigger = true; 
    public void PlayerOutTrigger() => isPlayerInTrigger = false; 
    public void StartInterract() => possibleInteract = true;
    public void StopInterract() => possibleInteract = false;
    public void ShowInteractionPanel(bool state) => UIManager.instance.ShowInteractablePanel(state);
}
