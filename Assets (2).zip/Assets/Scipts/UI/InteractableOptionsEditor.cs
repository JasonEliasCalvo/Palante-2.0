using System.Collections;
using System.Collections.Generic;
using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(InteractableOptions))]
public class InteractableOptionsEditor : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        InteractableOptions options = (InteractableOptions)target;
        options.InteractionType = (InteractionType)EditorGUILayout.EnumPopup("Selecionar opcion", options.InteractionType);
        switch (options.InteractionType)
        {
            case InteractionType.GenerateCards:
                break;

            case InteractionType.StartDialogue:
                options.ID = EditorGUILayout.IntField("ID", options.ID);
                break;

            case InteractionType.StartMoving:
                options.MovableObject = (MovableObject)EditorGUILayout.ObjectField("Objeto", options.MovableObject, typeof(MovableObject), true);
                break;

            case InteractionType.StartTypingGame:
                break;
        }
        serializedObject.ApplyModifiedProperties();
    }
}
